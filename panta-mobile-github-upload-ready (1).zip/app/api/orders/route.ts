import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { makeOrderNumber } from "@/lib/utils";
import { esewaConfig, esewaSignature, khaltiBase } from "@/lib/payments";

const schema=z.object({customerName:z.string().min(2),email:z.string().email(),phone:z.string().min(7),address:z.string().min(5),city:z.string().min(2),notes:z.string().optional(),gateway:z.enum(["COD","ESEWA","KHALTI"]),items:z.array(z.object({id:z.string(),name:z.string(),price:z.number(),quantity:z.number().int().min(1),image:z.string().optional()})).min(1)});

export async function POST(req:Request){
  try{
    const body=schema.parse(await req.json());
    const ids=body.items.map(i=>i.id);
    const products=await prisma.product.findMany({where:{id:{in:ids},active:true}});
    if(products.length!==ids.length)return NextResponse.json({error:"One or more products are unavailable."},{status:400});
    const byId=new Map(products.map(p=>[p.id,p]));
    for(const item of body.items){const p=byId.get(item.id);if(!p||p.stock<item.quantity)return NextResponse.json({error:`Insufficient stock for ${item.name}.`},{status:400});}
    const subtotal=body.items.reduce((s,i)=>s+i.price*i.quantity,0);const deliveryFee=subtotal>=5000?0:150;const total=subtotal+deliveryFee;const orderNumber=makeOrderNumber();
    const order=await prisma.$transaction(async tx=>{for(const item of body.items){await tx.product.update({where:{id:item.id},data:{stock:{decrement:item.quantity}}})}return tx.order.create({data:{orderNumber,customerName:body.customerName,email:body.email,phone:body.phone,address:body.address,city:body.city,notes:body.notes,subtotal,deliveryFee,total,status:body.gateway==="COD"?"CONFIRMED":"PENDING",paymentStatus:body.gateway==="COD"?"UNPAID":"PENDING",paymentGateway:body.gateway,transactionUuid:body.gateway==="ESEWA"?orderNumber:undefined,items:{create:body.items.map(i=>({productId:i.id,name:i.name,price:i.price,quantity:i.quantity,image:i.image}))}}})});
    if(body.gateway==="COD")return NextResponse.json({orderNumber:order.orderNumber});
    const base=process.env.NEXT_PUBLIC_SITE_URL||new URL(req.url).origin;
    if(body.gateway==="KHALTI"){
      const r=await fetch(`${khaltiBase()}/epayment/initiate/`,{method:"POST",headers:{Authorization:`Key ${process.env.KHALTI_SECRET_KEY||""}`,"Content-Type":"application/json"},body:JSON.stringify({return_url:`${base}/api/payments/khalti/callback`,website_url:base,amount:total*100,purchase_order_id:order.orderNumber,purchase_order_name:`Panta Mobile ${order.orderNumber}`,customer_info:{name:body.customerName,email:body.email,phone:body.phone}})});
      const d=await r.json();if(!r.ok||!d.payment_url)return NextResponse.json({error:d.detail||"Khalti initiation failed"},{status:502});
      return NextResponse.json({orderNumber:order.orderNumber,paymentUrl:d.payment_url});
    }
    const uuid=order.orderNumber;const cfg=esewaConfig();const totalText=String(total);const fields={amount:totalText,tax_amount:"0",product_service_charge:"0",product_delivery_charge:String(deliveryFee),product_code:cfg.productCode,total_amount:totalText,transaction_uuid:uuid,success_url:`${base}/api/payments/esewa`,failure_url:`${base}/order/${order.orderNumber}?payment=failed`,signed_field_names:"total_amount,transaction_uuid,product_code",signature:esewaSignature(totalText,uuid,cfg.productCode)};
    return NextResponse.json({orderNumber:order.orderNumber,payment:{action:cfg.url,fields}});
  }catch(e){return NextResponse.json({error:e instanceof z.ZodError?e.issues[0]?.message:"Could not create order."},{status:400});}
}

export async function GET(){return new Response("Khalti callback is handled at /api/payments/khalti/callback",{status:200})}

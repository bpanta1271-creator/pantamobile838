import { notFound } from "next/navigation";
import { prisma } from "@/lib/prisma";
import { ProductCard } from "@/components/ProductCard";
export default async function Category({params}:{params:Promise<{slug:string}>}){const {slug}=await params;const c=await prisma.category.findUnique({where:{slug},include:{products:{where:{active:true},include:{images:true},orderBy:{createdAt:"desc"}}}});if(!c)notFound();return <main><div className="container"><div className="page-head"><span className="eyebrow">Category</span><h1>{c.name}</h1><p className="muted">{c.description||"Explore this Panta Mobile collection."}</p></div><div className="grid">{c.products.map(p=><ProductCard key={p.id} product={p}/>)}</div></div></main>}

import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

const products = [
  { name: "Panta Everyday Android", slug: "panta-everyday-android", brand: "Android", price: 12999, comparePrice: 14999, stock: 12, featured: true, description: "A practical Android smartphone for everyday calls, social media and entertainment.", image: "/images/store-8.jpg" },
  { name: "Premium Android Pro", slug: "premium-android-pro", brand: "Android", price: 24999, comparePrice: 28999, stock: 7, featured: true, description: "A premium smartphone option with a modern design and a smooth everyday experience.", image: "/images/store-13.jpg" },
  { name: "Feature Phone Classic", slug: "feature-phone-classic", brand: "Feature Phone", price: 1800, comparePrice: 2100, stock: 25, featured: true, description: "Simple, dependable mobile phone for calls, texts and long battery life.", image: "/images/store-7.jpg" },
  { name: "Fast Charge Adapter", slug: "fast-charge-adapter", brand: "Accessories", price: 899, comparePrice: 1099, stock: 40, featured: true, description: "Compact charging adapter for compatible smartphones and accessories.", image: "/images/store-18.jpg" },
  { name: "Protective Phone Case", slug: "protective-phone-case", brand: "Accessories", price: 499, comparePrice: 699, stock: 60, featured: false, description: "Everyday protective case with a clean premium finish.", image: "/images/store-20.jpg" },
  { name: "Wireless Earbuds", slug: "wireless-earbuds", brand: "Audio", price: 1499, comparePrice: 1799, stock: 18, featured: true, description: "Compact wireless earbuds for calls, music and daily use.", image: "/images/store-19.jpg" },
  { name: "Tempered Glass", slug: "tempered-glass", brand: "Accessories", price: 299, comparePrice: 399, stock: 80, featured: false, description: "Screen protection for supported phone models.", image: "/images/store-21.jpg" },
  { name: "Mobile Repair Service", slug: "mobile-repair-service", brand: "Service", price: 500, comparePrice: undefined, stock: 999, featured: true, description: "Book a mobile repair assessment. Final cost depends on diagnosis and parts.", image: "/images/store-4.jpg" }
];

async function main() {
  const categoryMap: Record<string, string> = {};
  for (const c of [
    ["Smartphones", "smartphones"],
    ["Feature Phones", "feature-phones"],
    ["Accessories", "accessories"],
    ["Audio", "audio"],
    ["Repair & Services", "repair-services"]
  ] as const) {
    const category = await prisma.category.upsert({ where: { slug: c[1] }, update: { name: c[0] }, create: { name: c[0], slug: c[1] } });
    categoryMap[c[1]] = category.id;
  }

  for (const p of products) {
    const categorySlug = p.slug.includes("repair") ? "repair-services" : p.brand === "Feature Phone" ? "feature-phones" : p.brand === "Accessories" ? "accessories" : p.brand === "Audio" ? "audio" : "smartphones";
    const product = await prisma.product.upsert({
      where: { slug: p.slug },
      update: { name:p.name, slug:p.slug, brand:p.brand, price:p.price, comparePrice:p.comparePrice ?? null, stock:p.stock, featured:p.featured, description:p.description, categoryId: categoryMap[categorySlug] },
      create: { name:p.name, slug:p.slug, brand:p.brand, price:p.price, comparePrice:p.comparePrice ?? null, stock:p.stock, featured:p.featured, description:p.description, categoryId: categoryMap[categorySlug], images: { create: [{ url: p.image, alt: p.name }] } }
    });
    const imageCount = await prisma.productImage.count({ where: { productId: product.id } });
    if (!imageCount) await prisma.productImage.create({ data: { productId: product.id, url: p.image, alt: p.name } });
  }

  console.log("Seed complete.");
}

main().finally(() => prisma.$disconnect());
